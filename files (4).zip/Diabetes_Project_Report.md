# Diabetes Risk Analysis and Prediction (Healthcare Data Project)

**Domain:** Health / medical data analysis
**Dataset:** Pima Indians Diabetes Database (768 female patients aged 21+, 8 clinical measurements, binary outcome)
**Question:** Which clinical factors are linked to diabetes, and can a model flag high-risk patients for screening?
**Code:** `diabetes_project.py` (numbers below come from `project_stats.txt`)

---

## 1. Data quality: the hidden problem

The file has no blank cells, but five measurements contain **zeros that are physiologically impossible** (a glucose or blood pressure of 0, for example). These are missing values disguised as data.

| Feature | Zeros (hidden missing) | % |
|---|---|---|
| Insulin | 374 | 48.7% |
| Skin thickness | 227 | 29.6% |
| Blood pressure | 35 | 4.6% |
| BMI | 11 | 1.4% |
| Glucose | 5 | 0.7% |

Treating these zeros as real values would badly distort the averages (a zero-heavy insulin column looks far lower than it is). I converted them to missing values. In total **376 of 768 rows (49%) have at least one**. Imputation (median) happens **inside the model pipeline**, fitted on training folds only, so no test information leaks into preprocessing.

Class balance: 34.9% of patients are diabetic, so a model that always predicts "no diabetes" would already score 64.9% accuracy. Accuracy alone is therefore a poor metric here.

![EDA](fig_eda.png)

## 2. Exploratory findings

| Factor | Non-diabetic mean | Diabetic mean | Correlation with outcome |
|---|---|---|---|
| Glucose | 110.6 | 142.3 | **0.49** |
| BMI | 30.9 | 35.4 | 0.31 |
| Insulin | 130.3 | 206.8 | 0.30 |
| Age | 31.2 | 37.1 | 0.24 |
| Pregnancies | 3.3 | 4.9 | 0.22 |

All eight features differ significantly between groups (Mann-Whitney, p < 1e-5), but glucose has by far the largest effect.

**Risk gradients (share of patients who are diabetic):**
- **Glucose:** below 100 → 9%; 100-125 → 28%; 125-150 → 45%; above 150 → **75%**
- **BMI:** below 25 → 6%; 25-30 → 24%; above 30 → 45-47% (the rate does not rise further above 35)
- **Age:** 21-30 → 22%; 31-50 → 48-57%; 51+ → 47%

## 3. Predictive modeling

Setup: 80/20 stratified split (614 train, 154 test), 5-fold cross-validation, and three models. Class weighting was used for Logistic Regression and Random Forest. The final model was selected on **cross-validation AUC, not test AUC**, so the test set stayed untouched for the final evaluation.

| Model | CV AUC | Test AUC | Recall | Precision | F1 |
|---|---|---|---|---|---|
| **Logistic Regression** | **0.844** | 0.813 | 0.704 | 0.603 | 0.650 |
| Random Forest | 0.836 | 0.820 | 0.685 | 0.627 | 0.655 |
| Gradient Boosting | 0.825 | 0.813 | 0.519 | 0.622 | 0.566 |

The three models are statistically indistinguishable (CV standard deviations are about 0.02), so the simplest and most interpretable one, **Logistic Regression**, was chosen.

### Screening mode: choosing the threshold by the clinical goal
For a screening tool, missing a diabetic patient is costlier than sending a healthy one for a follow-up test. I picked the decision threshold using **training-set out-of-fold predictions only**, targeting at least 80% recall, which gave a threshold of 0.41.

| | Recall | Precision | Missed cases (FN) | False alarms (FP) |
|---|---|---|---|---|
| Default threshold 0.50 | 0.70 | 0.60 | 16 | 25 |
| **Screening threshold 0.41** | **0.81** | 0.57 | **10** | 33 |

On the 54 diabetic patients in the test set, the screening threshold catches 44 instead of 38, at the cost of 8 more false alarms. The trade-off should be decided by clinicians, not by the data scientist.

![Model evaluation](fig_model.png)

## 4. What drives the prediction

- **Glucose dominates.** Shuffling it drops test AUC by 0.157, over five times more than any other feature (BMI 0.029, pregnancies 0.027). Per 1 standard deviation, glucose carries an odds ratio of 3.27 and BMI 2.03.
- **Insulin, skin thickness and blood pressure add almost nothing** once glucose and BMI are known. This is partly because of their high missing rates (49% and 30% imputed), so their weak contribution may reflect poor data rather than low clinical relevance.

## 5. Conclusions

1. Glucose level is the single strongest indicator of diabetes in this dataset, and risk rises steadily across glucose bands (9% to 75%).
2. A simple, interpretable logistic regression reaches about 0.81 test AUC, matching more complex models, so complexity is not worth it here.
3. Threshold choice matters more than model choice: moving from 0.50 to 0.41 raises recall from 70% to 81%.
4. Data cleaning was essential. Nearly half the rows contain disguised missing values.

## 6. Limitations (read before drawing real-world conclusions)

- **Narrow population:** all patients are women of Pima heritage aged 21 or older. The results should not be generalized to other populations.
- **Small test set:** 154 patients (54 positive), so metrics carry wide uncertainty; a 1-2 point difference between models means nothing.
- **Imputation:** median imputation of insulin (49% missing) is a rough fix. Multiple imputation or collecting real values would be better.
- **Moderate performance:** a precision of about 0.57 means roughly 4 in 10 flagged patients do not have diabetes. This is a decision-support illustration, not a diagnostic tool.
- **No causal claims:** the data are observational.

## 7. Next steps

Try multiple imputation, add calibration checks and confidence intervals (bootstrap), and validate on an independent diabetes dataset.
