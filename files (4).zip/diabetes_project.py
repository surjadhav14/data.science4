"""
Real-World Health Data Project - Diabetes Risk (Pima Indians dataset)
End-to-end: cleaning -> EDA -> modeling -> threshold selection -> interpretation
Usage: python diabetes_project.py [pima_raw.csv]
Outputs: fig_eda.png, fig_model.png, project_stats.txt, diabetes_clean.csv
"""
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, cross_val_predict
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (roc_auc_score, average_precision_score, roc_curve, precision_recall_curve,
                             confusion_matrix, ConfusionMatrixDisplay, recall_score, precision_score,
                             accuracy_score, f1_score)

PATH = sys.argv[1] if len(sys.argv) > 1 else "pima_raw.csv"
SEED = 42
sns.set_theme(style="whitegrid", palette="deep")
out = []
def log(m=""):
    print(m); out.append(str(m))

COLS = ["pregnancies", "glucose", "blood_pressure", "skin_thickness", "insulin", "bmi", "pedigree", "age", "outcome"]
df = pd.read_csv(PATH, header=None, names=COLS)

# ============================================================ 1. DATA QUALITY
log("=== 1. DATA QUALITY ===")
log(f"shape {df.shape} | duplicates {df.duplicated().sum()} | class balance (diabetic) {df.outcome.mean():.1%}")
# Zeros are physiologically impossible for these measurements -> they encode MISSING data.
IMPOSSIBLE_ZERO = ["glucose", "blood_pressure", "skin_thickness", "insulin", "bmi"]
zeros = (df[IMPOSSIBLE_ZERO] == 0).sum()
log("hidden missing values (recorded as 0):\n" + pd.DataFrame({"n": zeros, "pct": (zeros / len(df) * 100).round(1)}).to_string())
df[IMPOSSIBLE_ZERO] = df[IMPOSSIBLE_ZERO].replace(0, np.nan)
log(f"rows with >=1 hidden missing value: {df.isna().any(axis=1).sum()} of {len(df)}")
df.to_csv("diabetes_clean.csv", index=False)   # NaN kept; imputation happens inside the model pipeline (no leakage)

# ============================================================ 2. EDA
log("\n=== 2. EDA ===")
feat = COLS[:-1]
log("mean by outcome:\n" + df.groupby("outcome")[feat].mean().round(1).to_string())
log("\nMann-Whitney U (diabetic vs not) with effect size (rank-biserial):")
eda_rows = []
for c in feat:
    a, b = df[df.outcome == 1][c].dropna(), df[df.outcome == 0][c].dropna()
    u, p = stats.mannwhitneyu(a, b)
    rb = 2 * u / (len(a) * len(b)) - 1
    eda_rows.append((c, rb, p))
    log(f"  {c:15s} effect={rb:+.2f}  p={p:.1e}")
corr = df.corr(numeric_only=True)
log("\ncorrelation with outcome:\n" + corr["outcome"].drop("outcome").sort_values(ascending=False).round(2).to_string())
df["bmi_band"] = pd.cut(df.bmi, [0, 25, 30, 35, 100], labels=["<25", "25-30", "30-35", "35+"])
df["age_band"] = pd.cut(df.age, [20, 30, 40, 50, 100], labels=["21-30", "31-40", "41-50", "51+"])
df["glucose_band"] = pd.cut(df.glucose, [0, 100, 125, 150, 250], labels=["<100", "100-125", "125-150", "150+"])
for b in ["bmi_band", "age_band", "glucose_band"]:
    log(f"\ndiabetes rate by {b}:\n" + df.groupby(b, observed=True).outcome.agg(["mean", "count"]).round(2).to_string())

fig, ax = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle("Diabetes Risk - Exploratory Analysis", fontsize=20, fontweight="bold")
miss = df[IMPOSSIBLE_ZERO].isna().mean().mul(100).sort_values()
ax[0, 0].barh(miss.index, miss.values, color="#c44e52"); ax[0, 0].set_title("Hidden missing values (zeros) %")
sns.kdeplot(data=df, x="glucose", hue="outcome", fill=True, common_norm=False, ax=ax[0, 1]); ax[0, 1].set_title("Glucose by outcome")
sns.boxplot(data=df, x="outcome", y="bmi", hue="outcome", ax=ax[0, 2], legend=False); ax[0, 2].set_title("BMI by outcome")
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, cbar=False, ax=ax[1, 0], annot_kws={"size": 7})
ax[1, 0].set_title("Correlation matrix")
for a_, b_ in [(ax[1, 1], "age_band"), (ax[1, 2], "glucose_band")]:
    r = df.groupby(b_, observed=True).outcome.mean()
    sns.barplot(x=r.index.astype(str), y=r.values, ax=a_, color="#4c72b0")
    a_.set_title(f"Diabetes rate by {b_.replace('_', ' ')}"); a_.set_ylabel("rate"); a_.set_ylim(0, 1)
plt.tight_layout(); plt.savefig("fig_eda.png", dpi=140); plt.close()
df = df.drop(columns=["bmi_band", "age_band", "glucose_band"])

# ============================================================ 3. MODELING
log("\n=== 3. MODELING ===")
X, y = df[feat], df["outcome"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
log(f"train {X_tr.shape} test {X_te.shape} | positives train {y_tr.mean():.1%} test {y_te.mean():.1%}")

def pipe(model, scale=True):
    steps = [("imp", SimpleImputer(strategy="median"))]    # fitted on train folds only
    if scale: steps.append(("sc", StandardScaler()))
    return Pipeline(steps + [("m", model)])

models = {
    "Logistic Regression": pipe(LogisticRegression(max_iter=1000, class_weight="balanced")),
    "Random Forest": pipe(RandomForestClassifier(n_estimators=400, min_samples_leaf=5, class_weight="balanced",
                                                  random_state=SEED), scale=False),
    "Gradient Boosting": pipe(GradientBoostingClassifier(n_estimators=150, max_depth=2, learning_rate=0.05,
                                                         random_state=SEED), scale=False),
}
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
rows, fitted, cv_means = [], {}, {}
for n, p in models.items():
    cv_auc = cross_val_score(p, X_tr, y_tr, cv=cv, scoring="roc_auc")
    cv_means[n] = cv_auc.mean()
    p.fit(X_tr, y_tr); proba = p.predict_proba(X_te)[:, 1]; pred = (proba >= .5).astype(int)
    fitted[n] = (p, proba)
    rows.append({"Model": n, "CV AUC": f"{cv_auc.mean():.3f}+/-{cv_auc.std():.3f}",
                 "Test AUC": roc_auc_score(y_te, proba), "PR-AUC": average_precision_score(y_te, proba),
                 "Accuracy": accuracy_score(y_te, pred), "Recall": recall_score(y_te, pred),
                 "Precision": precision_score(y_te, pred), "F1": f1_score(y_te, pred)})
res = pd.DataFrame(rows).set_index("Model")
log(res.round(3).to_string())
log(f"baseline (always 'no diabetes') accuracy on test: {1 - y_te.mean():.3f}")

best_name = max(cv_means, key=cv_means.get)   # select on CV (train) only, never on the test set
best, best_proba = fitted[best_name]
# --- screening threshold chosen on TRAIN out-of-fold predictions only (target recall >= 0.80)
oof = cross_val_predict(models[best_name], X_tr, y_tr, cv=cv, method="predict_proba")[:, 1]
prec, rec, thr = precision_recall_curve(y_tr, oof)
ok = np.where(rec[:-1] >= 0.80)[0]
T = thr[ok[-1]] if len(ok) else 0.5
pred_T = (best_proba >= T).astype(int)
log(f"\nbest model by CV AUC: {best_name}")
log(f"screening threshold (train OOF, recall>=0.80): {T:.2f}")
log(f"@0.50  recall {recall_score(y_te, (best_proba>=.5).astype(int)):.2f} precision {precision_score(y_te, (best_proba>=.5).astype(int)):.2f}")
log(f"@{T:.2f}  recall {recall_score(y_te, pred_T):.2f} precision {precision_score(y_te, pred_T):.2f} "
    f"accuracy {accuracy_score(y_te, pred_T):.2f}")
tn, fp, fn, tp = confusion_matrix(y_te, pred_T).ravel()
log(f"screening confusion: TP {tp} FN {fn} FP {fp} TN {tn}")

# --- interpretation: permutation importance on the held-out set
pi = permutation_importance(best, X_te, y_te, scoring="roc_auc", n_repeats=30, random_state=SEED)
imp = pd.Series(pi.importances_mean, index=feat).sort_values()
log("\npermutation importance (drop in AUC):\n" + imp.sort_values(ascending=False).round(3).to_string())
lr = models["Logistic Regression"]
coefs = pd.Series(lr.named_steps["m"].coef_[0], index=feat)
log("\nlogistic coefficients (per 1 SD, odds ratio):\n" + np.exp(coefs).sort_values(ascending=False).round(2).to_string())

# ============================================================ 4. FIGURE
fig, ax = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle("Diabetes Risk - Model Evaluation", fontsize=20, fontweight="bold")
for n, (_, pr) in fitted.items():
    f_, t_, _ = roc_curve(y_te, pr); ax[0, 0].plot(f_, t_, lw=2, label=f"{n} ({roc_auc_score(y_te, pr):.2f})")
ax[0, 0].plot([0, 1], [0, 1], "k--"); ax[0, 0].set_title("ROC curves"); ax[0, 0].legend(fontsize=8)
for n, (_, pr) in fitted.items():
    p_, r_, _ = precision_recall_curve(y_te, pr); ax[0, 1].plot(r_, p_, lw=2, label=n)
ax[0, 1].axhline(y_te.mean(), color="k", ls="--"); ax[0, 1].set_xlabel("Recall"); ax[0, 1].set_ylabel("Precision")
ax[0, 1].set_title("Precision-Recall curves"); ax[0, 1].legend(fontsize=8)
res[["Accuracy", "Recall", "Precision", "F1"]].astype(float).plot.bar(ax=ax[0, 2], rot=15, width=.8)
ax[0, 2].set_title("Metrics @ 0.50 threshold"); ax[0, 2].set_ylim(0, 1)
ConfusionMatrixDisplay(confusion_matrix(y_te, (best_proba >= .5).astype(int)), display_labels=["No", "Diabetes"]).plot(ax=ax[1, 0], cmap="Blues", colorbar=False)
ax[1, 0].set_title(f"{best_name} @ 0.50"); ax[1, 0].grid(False)
ConfusionMatrixDisplay(confusion_matrix(y_te, pred_T), display_labels=["No", "Diabetes"]).plot(ax=ax[1, 1], cmap="Oranges", colorbar=False)
ax[1, 1].set_title(f"Screening mode @ {T:.2f} (recall-first)"); ax[1, 1].grid(False)
imp.plot.barh(ax=ax[1, 2], color="#4c72b0"); ax[1, 2].set_title("Permutation importance (drop in AUC)")
plt.tight_layout(); plt.savefig("fig_model.png", dpi=140); plt.close()

open("project_stats.txt", "w").write("\n".join(out))
